package movie_ticket_booking_system;

import java.util.ArrayList;
import java.util.Scanner;

public class Customer extends User {
    private static final int ADULT_AGE = 18; // Minimum age for watching adult movies

    private ArrayList<Ticket> myTickets; // List of tickets booked by the customer
    private int age; // Customer's age

    // Constructor
    public Customer(String username, String password, String email, int age) {
        super(username, password, email); // Call to User constructor
        this.age = age;
        this.myTickets = new ArrayList<>(); // Initialize tickets list
    }

    // Override displayMenu
    @Override
    public void displayMenu() {
        System.out.println("\n=== Customer Menu ===");
        System.out.println("1. View Profile");
        System.out.println("2. Change Password");
        System.out.println("3. Change Email");
        System.out.println("4. View Available Movies");
        System.out.println("5. Book Ticket");
        System.out.println("6. View My Tickets");
        System.out.println("7. Cancel Ticket");
        System.out.println("8. Logout");
    }

    // View available movies
    public void viewAvailableMovies(ArrayList<Movie> movies) {
        System.out.println("\n=== Available Movies ===");
        if (movies.isEmpty()) {
            System.out.println("No movies are currently available.");
            return;
        }

        boolean hasMovies = false;
        for (Movie movie : movies) {
            if (canWatchMovie(movie)) {
                System.out.println(movie);
                System.out.println("------------------------");
                hasMovies = true;
            }
        }

        if (!hasMovies) {
            System.out.println("No movies available for your age group.");
        }
    }

    // Check if a customer can watch a movie based on their age
    protected boolean canWatchMovie(Movie movie) {
        if (movie instanceof AdultMovie) {
            return age >= ADULT_AGE;
        }
        return true;
    }

    // Book a ticket for a movie
    public void bookTicket(ArrayList<Movie> movies, ArrayList<Ticket> tickets, Scanner scanner) {
        System.out.println("\n=== Book a Ticket ===");

        if (movies.isEmpty()) {
            System.out.println("No movies available for booking.");
            return;
        }

        // Display available movies
        viewAvailableMovies(movies);

        System.out.print("Enter the title of the movie to book: ");
        String movieTitle = scanner.nextLine().trim();

        // Find the movie by title
        Movie selectedMovie = findMovieByTitle(movies, movieTitle);
        if (selectedMovie == null) {
            System.out.println("Movie not found. Please try again.");
            return;
        }

        if (!canWatchMovie(selectedMovie)) {
            System.out.println("You do not meet the age requirements to watch this movie.");
            return;
        }

        // Display seat availability
        selectedMovie.displaySeats();

        System.out.println("Select ticket type:\n1. Standard (Rows 1-3)\n2. Premium (Row 0)");
        int ticketType = getIntInput(scanner, "Enter your choice: ", 1, 2);

        if (ticketType == 1) {
            bookStandardTicket(selectedMovie, tickets, scanner);
        } else {
            bookPremiumTicket(selectedMovie, tickets, scanner);
        }
    }

    // Book a standard ticket
    private void bookStandardTicket(Movie movie, ArrayList<Ticket> tickets, Scanner scanner) {
        System.out.println("\n=== Book a Standard Ticket ===");
        int row = getIntInput(scanner, "Enter row (1-3): ", 1, 3);
        int column = getIntInput(scanner, "Enter column (0-2): ", 0, 2);

        if (checkSeatAvailability(movie, row, column)) {
            StandardTicket ticket = new StandardTicket(movie, row, column, this);
            ticket.setPromotionCode(scanner); // Allow customer to apply a promotion code
            tickets.add(ticket);
            myTickets.add(ticket);
            movie.setSeatStatus(row, column, "Booked");
            System.out.println("Standard ticket booked successfully!");
        }
    }

    // Book a premium ticket
    private void bookPremiumTicket(Movie movie, ArrayList<Ticket> tickets, Scanner scanner) {
        System.out.println("\n=== Book a Premium Ticket ===");
        int column = getIntInput(scanner, "Enter column (0-2): ", 0, 2);

        if (checkSeatAvailability(movie, 0, column)) {
            PremiumTicket ticket = new PremiumTicket(movie, 0, column, this);
            tickets.add(ticket);
            myTickets.add(ticket);
            movie.setSeatStatus(0, column, "Booked");
            System.out.println("Premium ticket booked successfully!");
        }
    }

    // Cancel a ticket
    public void cancelTicket(ArrayList<Ticket> tickets, Scanner scanner) {
        if (myTickets.isEmpty()) {
            System.out.println("You have no tickets to cancel.");
            return;
        }

        System.out.println("\n=== Cancel a Ticket ===");
        viewMyTickets();

        System.out.print("Enter the title of the movie for the ticket to cancel: ");
        String movieTitle = scanner.nextLine().trim();

        Ticket ticketToCancel = findTicketByMovieTitle(movieTitle);
        if (ticketToCancel == null) {
            System.out.println("No ticket found for the specified movie.");
            return;
        }

        // Cancel the ticket
        ticketToCancel.getMovie_Title().setSeatStatus(ticketToCancel.getSeatRow(), ticketToCancel.getSeatColumn(), "Available");
        myTickets.remove(ticketToCancel);
        tickets.remove(ticketToCancel);
        System.out.println("Ticket canceled successfully.");
    }

    // View all tickets booked by the customer
    public void viewMyTickets() {
        if (myTickets.isEmpty()) {
            System.out.println("You have no tickets booked.");
            return;
        }

        System.out.println("\n=== My Tickets ===");
        for (Ticket ticket : myTickets) {
            ticket.getTicketInfo();
            System.out.println("------------------------");
        }
    }

    // Helpers

    // Find a movie by its title
    private Movie findMovieByTitle(ArrayList<Movie> movies, String title) {
        for (Movie movie : movies) {
            if (movie.getTitle().equalsIgnoreCase(title)) {
                return movie;
            }
        }
        return null;
    }

    // Find a ticket by its movie title
    private Ticket findTicketByMovieTitle(String movieTitle) {
        for (Ticket ticket : myTickets) {
            if (ticket.getMovie_Title().getTitle().equalsIgnoreCase(movieTitle)) {
                return ticket;
            }
        }
        return null;
    }

    // Check if a seat is available
    private boolean checkSeatAvailability(Movie movie, int row, int column) {
        if ("Available".equals(movie.getSeats()[row][column])) {
            return true;
        } else {
            System.out.println("The selected seat is already booked. Please choose a different seat.");
            return false;
        }
    }

    // Get integer input with validation
    private int getIntInput(Scanner scanner, String prompt, int min, int max) {
        int input;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                if (input >= min && input <= max) {
                    return input;
                }
            } else {
                scanner.nextLine(); // Clear invalid input
            }
            System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
        }
    }

    // Getters
    public int getAge() {
        return age;
    }

    // Override getUserInfo to include customer-specific details
    @Override
    public void getUserInfo() {
        super.getUserInfo();
        System.out.println("Age: " + age);
        System.out.println("Number of tickets booked: " + myTickets.size());
    }
}
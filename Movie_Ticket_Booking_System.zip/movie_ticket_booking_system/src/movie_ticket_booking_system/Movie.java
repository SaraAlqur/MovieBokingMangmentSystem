package movie_ticket_booking_system;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

enum Genre {
    ACTION, COMEDY, DRAMA, HORROR, SCIFI, ANIMATION
}

public abstract class Movie {
    private static final int MIN_DURATION = 30;
    private static final int MAX_DURATION = 300;
    private static final double MIN_RATING = 0.0;
    private static final double MAX_RATING = 5.0;
    private static final int ROWS = 4; // 4 rows: 0 for premium, 1-3 for standard
    private static final int COLUMNS = 3; // 3 seats per row

    private String title;
    private String description;
    private Genre genre;
    private int duration;
    private double rating;
    private String ageRating;
    private String[][] seats;
    private LocalDate showtime;

    // Constructor
    public Movie(String title, String description, Genre genre, int duration,
                 double rating, String ageRating, int month, int day) {
        setTitle(title);
        setDescription(description);
        setGenre(genre);
        setDuration(duration);
        setRating(rating);
        setAgeRating(ageRating);
        setShowtime(month, day);
        initializeSeats();
    }

    // Initialize seats
    private void initializeSeats() {
        seats = new String[ROWS][COLUMNS];
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                seats[i][j] = "Available";
            }
        }
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Genre getGenre() {
        return genre;
    }

    public int getDuration() {
        return duration;
    }

    public double getRating() {
        return rating;
    }

    public String getAgeRating() {
        return ageRating;
    }

    public LocalDate getShowtime() {
        return showtime;
    }

    public String[][] getSeats() {
        String[][] seatsCopy = new String[ROWS][COLUMNS];
        for (int i = 0; i < seats.length; i++) {
            System.arraycopy(seats[i], 0, seatsCopy[i], 0, seats[i].length);
        }
        return seatsCopy;
    }

    // Setters with validation
    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty() || title.length() > 100) {
            throw new IllegalArgumentException("Error: Title must be between 1 and 100 characters.");
        }
        this.title = title.trim();
    }

    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty() || description.length() > 300) {
            throw new IllegalArgumentException("Error: Description must be between 1 and 300 characters.");
        }
        this.description = description.trim();
    }

    public void setGenre(Genre genre) {
        if (genre == null) {
            throw new IllegalArgumentException("Error: Genre cannot be null.");
        }
        this.genre = genre;
    }

    public void setDuration(int duration) {
        if (duration < MIN_DURATION || duration > MAX_DURATION) {
            throw new IllegalArgumentException("Error: Duration must be between " + MIN_DURATION + " and " + MAX_DURATION + " minutes.");
        }
        this.duration = duration;
    }

    public void setRating(double rating) {
        if (rating < MIN_RATING || rating > MAX_RATING) {
            throw new IllegalArgumentException("Error: Rating must be between " + MIN_RATING + " and " + MAX_RATING + ".");
        }
        this.rating = rating;
    }

    public void setAgeRating(String ageRating) {
        if (ageRating == null || ageRating.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Age rating cannot be empty.");
        }
        this.ageRating = ageRating.trim();
    }

    public void setShowtime(int month, int day) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Error: Invalid month. Must be between 1 and 12.");
        }
        if (day < 1 || day > 31) {
            throw new IllegalArgumentException("Error: Invalid day. Must be between 1 and 31.");
        }
        this.showtime = LocalDate.of(2025, month, day);
    }

    // Manage seat status
    public void setSeatStatus(int row, int column, String status) {
        if (row < 0 || row >= ROWS || column < 0 || column >= COLUMNS) {
            System.out.println("Error: Invalid seat selection. Please choose a valid row and column.");
            return;
        }
        if (!status.equals("Available") && !status.equals("Booked")) {
            System.out.println("Error: Invalid seat status. Must be 'Available' or 'Booked'.");
            return;
        }
        seats[row][column] = status;
    }

    // Display seats
    public void displaySeats() {
        System.out.println("\n=== Seat Availability ===");
        for (int i = 0; i < seats.length; i++) {
            System.out.print("Row " + i + "\t");
            for (int j = 0; j < seats[i].length; j++) {
                System.out.print(seats[i][j].equals("Available") ? "[0] " : "[X] ");
            }
            System.out.println();
        }
        System.out.println("\n======= SCREEN =======\n");
    }

    // Format showtime
    public String getFormattedShowtime() {
        if (showtime == null) {
            return "No showtime set";
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return showtime.format(formatter);
    }

    // Get movie details
    public String[] getMovieInfo() {
        return new String[]{
            "Title: " + title,
            "Description: " + description,
            "Genre: " + genre,
            "Duration: " + duration + " minutes",
            "Rating: " + rating + "/5.0",
            "Age Rating: " + ageRating,
            "Show Time: " + getFormattedShowtime()
        };
    }

    // Override toString
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String info : getMovieInfo()) {
            sb.append(info).append("\n");
        }
        return sb.toString();
    }
}
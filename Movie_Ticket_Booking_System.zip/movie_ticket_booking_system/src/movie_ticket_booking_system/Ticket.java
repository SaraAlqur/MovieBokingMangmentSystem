package movie_ticket_booking_system;

import java.time.DayOfWeek;
import java.time.LocalDate;

public abstract class Ticket {
    // Constants
    private static final double BASE_PRICE = 50.0;
    private static final double WEEKEND_SURCHARGE = 10.0;
    private static final int MAX_ROW = 4; // Number of rows in seating
    private static final int MAX_COLUMN = 3; // Number of columns in seating

    // Private member variables
    private Movie movie;
    private int seatRow;
    private int seatColumn;
    private Customer customer;
    private double price;

    // Constructor
    public Ticket(Movie movie, int seatRow, int seatColumn, Customer customer) {
        validateTicketInputs(movie, seatRow, seatColumn, customer);

        this.movie = movie;
        this.seatRow = seatRow;
        this.seatColumn = seatColumn;
        this.customer = customer;
        this.price = calculatePrice();

        // Mark seat as booked
        markSeatAsBooked();
    }

    // Input validation helper method
    private void validateTicketInputs(Movie movie, int seatRow, int seatColumn, Customer customer) {
        if (movie == null) {
            throw new IllegalArgumentException("Error: Movie cannot be null.");
        }
        if (customer == null) {
            throw new IllegalArgumentException("Error: Customer cannot be null.");
        }
        if (seatRow < 0 || seatRow >= MAX_ROW) {
            throw new IllegalArgumentException("Error: Invalid row selection. Must be between 0 and " + (MAX_ROW - 1) + ".");
        }
        if (seatColumn < 0 || seatColumn >= MAX_COLUMN) {
            throw new IllegalArgumentException("Error: Invalid column selection. Must be between 0 and " + (MAX_COLUMN - 1) + ".");
        }
        if (!isSeatAvailable(movie, seatRow, seatColumn)) {
            throw new IllegalArgumentException("Error: Selected seat (Row " + seatRow + ", Column " + seatColumn + ") is not available.");
        }
    }

    // Helper method to check seat availability
    public boolean isSeatAvailable(Movie movie, int row, int column) {
        String[][] seats = movie.getSeats();
        return seats[row][column].equalsIgnoreCase("Available");
    }

    // Mark seat as booked in the movie's seating arrangement
    private void markSeatAsBooked() {
        movie.setSeatStatus(seatRow, seatColumn, "Booked");
    }

    // Calculate ticket price
    public double calculatePrice() {
        double finalPrice = BASE_PRICE;

        // Add weekend surcharge if applicable
        if (isWeekend()) {
            finalPrice += WEEKEND_SURCHARGE;
        }

        return finalPrice;
    }

    // Check if movie showtime is on a weekend
    private boolean isWeekend() {
        LocalDate showTime = movie.getShowtime();
        DayOfWeek dayOfWeek = showTime.getDayOfWeek();
        return dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY;
    }

    // Get ticket information
    public void getTicketInfo() {
        System.out.println("=== Ticket Information ===");
        System.out.println("Movie: " + movie.getTitle());
        System.out.println("Show Time: " + movie.getFormattedShowtime());
        System.out.println("Seat: Row " + seatRow + ", Column " + seatColumn);
        System.out.println("Customer: " + customer.getUsername());
        System.out.println("Price: $" + String.format("%.2f", price));
    }

    // Getters
    public Movie getMovie_Title() {
        return movie;
    }

    public int getSeatRow() {
        return seatRow;
    }

    public int getSeatColumn() {
        return seatColumn;
    }

    public Customer getCustomer() {
        return customer;
    }

    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    // Cancel ticket
    public void cancelTicket() {
        // Mark seat as available again
        movie.setSeatStatus(seatRow, seatColumn, "Available");
        System.out.println("The seat (Row " + seatRow + ", Column " + seatColumn + ") has been released.");
    }

    // Override toString method
    @Override
    public String toString() {
        return String.format(
            "Movie: %s%nShow Time: %s%nSeat: Row %d, Column %d%nCustomer: %s%nPrice: $%.2f",
            movie.getTitle(),
            movie.getFormattedShowtime(),
            seatRow,
            seatColumn,
            customer.getUsername(),
            price
        );
    }
}
package movie_ticket_booking_system;

import java.util.ArrayList;
import java.util.Scanner;

public class Admin extends User {
    // Constants for admin credentials and validation rules
    private static final String ADMIN_USERNAME = "admin123";
    private static final String ADMIN_PASSWORD = "adminpass";
    private static final String ADMIN_EMAIL = "admin@moviebooking.com";

    private static final int MIN_TITLE_LENGTH = 1;
    private static final int MAX_TITLE_LENGTH = 50;
    private static final int MIN_DESCRIPTION_LENGTH = 10;
    private static final int MAX_DESCRIPTION_LENGTH = 200;

    // Scanner for input handling
    private final Scanner scanner;

    // Constructor
    public Admin() {
        super(ADMIN_USERNAME, ADMIN_PASSWORD, ADMIN_EMAIL);
        this.scanner = new Scanner(System.in);
    }

    // Override displayMenu
    @Override
    public void displayMenu() {
        System.out.println("\n=== Admin Menu ===");
        System.out.println("1. View Profile");
        System.out.println("2. Change Password");
        System.out.println("3. Change Email");
        System.out.println("4. View All Movies");
        System.out.println("5. Add Movie");
        System.out.println("6. Remove Movie");
        System.out.println("7. View All Tickets");
        System.out.println("8. Logout");
    }

    // Method to view all movies
    public void viewAllMovies(ArrayList<Movie> movies) {
        if (movies.isEmpty()) {
            System.out.println("No movies available in the system.");
            return;
        }
        System.out.println("\n=== All Movies ===");
        for (Movie movie : movies) {
            System.out.println("------------------------");
            System.out.println(movie);
        }
    }

    // Method to view all tickets
    public void viewAllTickets(ArrayList<Ticket> tickets) {
        if (tickets.isEmpty()) {
            System.out.println("No tickets have been booked yet.");
            return;
        }
        System.out.println("\n=== All Booked Tickets ===");
        for (Ticket ticket : tickets) {
            System.out.println("------------------------");
            ticket.getTicketInfo();
        }
    }

    // Method to add a new movie
    public void addMovie(ArrayList<Movie> movies) {
        System.out.println("\n=== Add a New Movie ===");

        // Get movie details from admin
        String title = getInput("Enter movie title: ", MIN_TITLE_LENGTH, MAX_TITLE_LENGTH);
        String description = getInput("Enter movie description: ", MIN_DESCRIPTION_LENGTH, MAX_DESCRIPTION_LENGTH);

        System.out.println("Select Genre:");
        Genre genre = getMovieGenre();

        int duration = getIntInput("Enter movie duration in minutes (30-300): ", 30, 300);

        double rating = getInput("Enter movie rating (0.0-5.0): ", 0.0, 5.0);

        System.out.println("Select Age Rating:\n1. G\n2. PG\n3. PG-13\n4. R");
        String ageRating = getAgeRating();

        int month = getIntInput("Enter release month (1-12): ", 1, 12);
        int day = getValidDay(month);

        // Ask if the movie is for Adults or Children
        System.out.println("Is this movie:\n1. Adult Movie\n2. Children's Movie");
        int movieType = getIntInput("Choose an option: ", 1, 2);

        if (movieType == 1) {
            // Adult Movie
            System.out.print("Enter Lead Actor: ");
            String leadActor = scanner.nextLine().trim();
            System.out.print("Enter Director: ");
            String director = scanner.nextLine().trim();
            System.out.println("Select Violence Level: \n1. Low\n2. Moderate\n3. High");
            String violenceLevel = getViolenceLevel();

            movies.add(new AdultMovie(title, description, genre, duration, rating, ageRating, month, day, leadActor, director, violenceLevel));
            System.out.println("Adult movie added successfully!");
        } else {
            // Children's Movie
            System.out.println("Enter Movie Type (eg. Animation, musical): ");
            String movieTypeStr = scanner.nextLine().trim().toUpperCase();
            
            
            System.out.print("Is this movie educational? (Yes/No): ");
            String isEducational = scanner.nextLine().trim().toUpperCase();

            movies.add(new ChildrenMovie(title, description, genre, duration, rating, ageRating, month, day, movieTypeStr, isEducational));
            System.out.println("Children's movie added successfully!");
        }
    }

    // Method to remove a movie
    public void removeMovie(ArrayList<Movie> movies) {
        if (movies.isEmpty()) {
            System.out.println("No movies available to remove.");
            return;
        }

        System.out.println("\n=== Remove a Movie ===");
        viewAllMovies(movies);

        System.out.print("Enter the title of the movie to remove: ");
        String title = scanner.nextLine().trim();

        Movie movieToRemove = findMovieByTitle(movies, title);
        if (movieToRemove != null) {
            movies.remove(movieToRemove);
            System.out.println("Movie '" + title + "' has been removed successfully.");
        } else {
            System.out.println("Movie not found. Please check the title and try again.");
        }
    }

    // Helper methods

    private String getInput(String prompt, int minLength, int maxLength) {
        String input;
        do {
            System.out.print(prompt);
            input = scanner.nextLine().trim();
            if (input.length() < minLength || input.length() > maxLength) {
                System.out.println("Input must be between " + minLength + " and " + maxLength + " characters.");
            }
        } while (input.length() < minLength || input.length() > maxLength);
        return input;
    }

    private int getIntInput(String prompt, int min, int max) {
        int input;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                if (input >= min && input <= max) {
                    return input;
                }
            } else {
                scanner.nextLine(); // Clear invalid input
            }
            System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
        }
    }

    private double getInput(String prompt, double min, double max) {
        double input;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextDouble()) {
                input = scanner.nextDouble();
                scanner.nextLine(); // Consume newline
                if (input >= min && input <= max) {
                    return input;
                }
            } else {
                scanner.nextLine(); // Clear invalid input
            }
            System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
        }
    }

    private Genre getMovieGenre() {
        System.out.println("1. Action");
        System.out.println("2. Comedy");
        System.out.println("3. Drama");
        System.out.println("4. Horror");
        System.out.println("5. Sci-Fi");

        int choice = getIntInput("Choose a genre: ", 1, 5);
        switch (choice) {
            case 1: return Genre.ACTION;
            case 2: return Genre.COMEDY;
            case 3: return Genre.DRAMA;
            case 4: return Genre.HORROR;
            default: return Genre.SCIFI;
        }
    }

    private String getAgeRating() {
        int choice = getIntInput("Choose an age rating: ", 1, 4);
        switch (choice) {
            case 1: return "G";
            case 2: return "PG";
            case 3: return "PG-13";
            default: return "R";
        }
    }

    private int getValidDay(int month) {
        int maxDay;
        switch (month) {
            case 4: case 6: case 9: case 11:
                maxDay = 30; // Months with 30 days
                break;
            case 2:
                maxDay = 28; // February
                break;
            default:
                maxDay = 31; // Months with 31 days
                break;
        }
        return getIntInput("Enter day (1-" + maxDay + "): ", 1, maxDay);
    }

    private String getViolenceLevel() {
        int choice = getIntInput("Choose a violence level: ", 1, 3);
        switch (choice) {
            case 1: return "Low";
            case 2: return "Moderate";
            default: return "High";
        }
    }

    private Movie findMovieByTitle(ArrayList<Movie> movies, String title) {
        for (Movie movie : movies) {
            if (movie.getTitle().equalsIgnoreCase(title)) {
                return movie;
            }
        }
        return null;
    }
}
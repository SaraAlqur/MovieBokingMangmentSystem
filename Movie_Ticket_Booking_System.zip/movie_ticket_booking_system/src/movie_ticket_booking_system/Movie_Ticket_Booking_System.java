package movie_ticket_booking_system;

import java.util.ArrayList;
import java.util.Scanner;

public class Movie_Ticket_Booking_System {
    // Global variables
    private static final Scanner scanner = new Scanner(System.in);
    private static final ArrayList<Customer> customers = new ArrayList<>();
    private static final ArrayList<Movie> movies = new ArrayList<>();
    private static final ArrayList<Ticket> tickets = new ArrayList<>();
    private static final Admin admin = new Admin();

    public static void main(String[] args) {
        initializeSampleData(); // Load sample movies and customers for testing

        System.out.println("=== Welcome to the Movie Ticket Booking System! ===");
        while (true) {
            System.out.println("\n=== Main Menu ===");
            System.out.println("1. Login as Admin");
            System.out.println("2. Login as Customer");
            System.out.println("3. Register as Customer");
            System.out.println("4. Exit");

            int choice = getIntInput("Choose an option: ");
            switch (choice) {
                case 1:
                    adminLogin();
                    break;
                case 2:
                    customerLogin();
                    break;
                case 3:
                    registerCustomer();
                    break;
                case 4:
                    System.out.println("Thank you for using the Movie Ticket Booking System!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Load sample data for testing
    private static void initializeSampleData() {
        // Add sample movies
        movies.add(new AdultMovie("Inception", "A dream-sharing thriller.", Genre.SCIFI, 148, 4.8, "PG-13", 12, 25, "Leonardo DiCaprio", "Christopher Nolan", "Moderate"));
        movies.add(new ChildrenMovie("Frozen", "A magical journey of love and friendship.", Genre.ANIMATION, 102, 4.5, "PG", 11, 27, "ANIMATION", "Yes"));

        // Add sample customer
        customers.add(new Customer("john_doe", "password123", "john@example.com", 25));
    }

    // Admin login
    private static void adminLogin() {
        System.out.println("\n=== Admin Login ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
            System.out.println("Admin login successful!");
            adminMenu();
        } else {
            System.out.println("Invalid admin credentials. Please try again.");
        }
    }

    // Admin menu
    private static void adminMenu() {
        while (true) {
            admin.displayMenu();
            int choice = getIntInput("Choose an option: ");
            switch (choice) {
                case 1: // View Profile
                    admin.getUserInfo();
                    break;
                case 2: // Change Password
                    changePassword(admin);
                    break;
                case 3: // Change Email
                    changeEmail(admin);
                    break;
                case 4: // View All Movies
                    admin.viewAllMovies(movies);
                    break;
                case 5: // Add Movie
                    admin.addMovie(movies);
                    break;
                case 6: // Remove Movie
                    admin.removeMovie(movies);
                    break;
                case 7: // View All Tickets
                    admin.viewAllTickets(tickets);
                    break;
                case 8: // Logout
                    System.out.println("Logged out successfully.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Customer login
    private static void customerLogin() {
        System.out.println("\n=== Customer Login ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        for (Customer customer : customers) {
            if (customer.getUsername().equals(username) && customer.getPassword().equals(password)) {
                System.out.println("Login successful! Welcome, " + username + "!");
                customerMenu(customer);
                return;
            }
        }
        System.out.println("Invalid username or password. Please try again.");
    }

    // Customer menu
    private static void customerMenu(Customer customer) {
        while (true) {
            customer.displayMenu();
            int choice = getIntInput("Choose an option: ");
            switch (choice) {
                case 1: // View Profile
                    customer.getUserInfo();
                    break;
                case 2: // Change Password
                    changePassword(customer);
                    break;
                case 3: // Change Email
                    changeEmail(customer);
                    break;
                case 4: // View Available Movies
                    customer.viewAvailableMovies(movies);
                    break;
                case 5: // Book Ticket
                    customer.bookTicket(movies, tickets, scanner);
                    break;
                case 6: // View My Tickets
                    customer.viewMyTickets();
                    break;
                case 7: // Cancel Ticket
                    customer.cancelTicket(tickets, scanner);
                    break;
                case 8: // Logout
                    System.out.println("Logged out successfully.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Register a new customer
    private static void registerCustomer() {
        System.out.println("\n=== Register as New Customer ===");

        String username;
        String password;
        String email;
        
        do {
            System.out.print("Enter username: ");
            username = scanner.nextLine().trim();
            
            if (username.length() < 6) {
                System.out.println("Username must be at least 6 characters long. Try again please!");
            }
        } while (username.length() < 6);
        
        // Check for duplicate username
        for (Customer customer : customers) {
            if (customer.getUsername().equalsIgnoreCase(username)) {
                System.out.println("Username already exists. Log in through the main menu.");
                return;
            }
        }
        
        
        do {
            System.out.print("Enter password: ");
            password = scanner.nextLine().trim();
            
            if (password.length() < 6) {
                System.out.println("Password must be at least 6 characters long. Try again please!");
            }
        } while (password.length() < 6);
                    
        // Validate Email
        do {
            System.out.print("Enter email: ");
            email = scanner.nextLine().trim();
            if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                System.out.println("Please enter a valid email address.");
            }
        } while (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$"));
       
        
        
        int age = getIntInput("Enter your age: ");
        
        if(User.signUp(customers,username,password,email,age)){
        customers.add(new Customer(username, password, email, age));
        System.out.println("Registration successful! You can now log in as a customer.");}
    }

    // Change password for a user
    private static void changePassword(User user) {
        System.out.print("Enter your new password: ");
        String newPassword = scanner.nextLine().trim();
        user.setPassword(newPassword);
    }

    // Change email for a user
    private static void changeEmail(User user) {
        System.out.print("Enter your new email: ");
        String newEmail = scanner.nextLine().trim();
        user.setEmail(newEmail);
    }

    // Helper method to get integer input with validation
    private static int getIntInput(String prompt) {
        int input;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                return input;
            } else {
                scanner.nextLine(); // Clear invalid input
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
    }
}
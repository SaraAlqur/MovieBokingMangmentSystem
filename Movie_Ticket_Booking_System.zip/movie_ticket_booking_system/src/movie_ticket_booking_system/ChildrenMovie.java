package movie_ticket_booking_system;

public class ChildrenMovie extends Movie {
    // Constants
    private static final int MIN_AGE = 3; // Minimum recommended age
    private static final int MAX_AGE = 12; // Maximum recommended age

    // Attributes specific to children's movies
    private String movieType; // Type of children's movie (e.g., Animation, Musical)
    private String isEducational; // Whether the movie is educational ("Yes" or "No")

    // Constructor
    public ChildrenMovie(String title, String description, Genre genre, int duration, double rating,
                         String ageRating, int month, int day, String movieType, String isEducational) {
        super(title, description, genre, duration, rating, ageRating, month, day);

        // Validate and set movie type
        setMovieType(movieType);

        // Validate and set educational value
        setIsEducational(isEducational);

        // Validate age rating
        if (!"G".equals(ageRating) && !"PG".equals(ageRating)) {
            System.out.println("Invalid age rating for children's movie. Setting to 'PG'.");
            setAgeRating("PG");
        }
    }

    // Getters
    public String getMovieType() {
        return movieType;
    }

    public String getIsEducational() {
        return isEducational;
    }

    // Setters with validation
    public void setMovieType(String movieType) {
        if (movieType == null || movieType.trim().isEmpty() ) {
            System.out.println("Invalid movie type. Setting to 'Unknown'.");
            this.movieType = "Unknown";
        } else {
            this.movieType = movieType.trim();
        }
    }

    public void setIsEducational(String isEducational) {
        if (isEducational == null || isEducational.trim().isEmpty() || !(isEducational.equalsIgnoreCase("NO") || isEducational.equalsIgnoreCase("YES"))){
            System.out.println("Invalid educational value. Setting to 'No'.");
            this.isEducational = "No";
        } else {
            this.isEducational = isEducational.trim();
        }
    }

   

    // Method to check if the movie is age-appropriate for a viewer
    public boolean isAgeAppropriate(int viewerAge) {
        if (viewerAge < MIN_AGE) {
            System.out.println("This movie is not suitable for children under " + MIN_AGE + " years old.");
            return false;
        }
        return true;
    }

    // Override toString to include children's movie-specific details
    @Override
    public String toString() {
        return super.toString() +
               "Movie Type: " + movieType + "\n" +
               "Educational: " + isEducational + "\n" + getAgeRecommendation();
    }

    // Method to get a recommendation based on the age rating
    public String getAgeRecommendation() {
        if ("G".equals(getAgeRating())) {
            return "Suitable for all ages.";
        } else {
            return "Recommended for children aged " + MIN_AGE + " to " + MAX_AGE + ".";
        }
    }
}
package movie_ticket_booking_system;

import java.util.ArrayList;

public abstract class User {
    // Constants for validation

    private static final int MIN_PASSWORD_LENGTH = 6;
    private static final int MIN_AGE = 13;
    private static final int MAX_AGE = 100;
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@(.+)$";
    
    // User attributes
    private String username;
    private String password;
    private String email;

    // Constructor
    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    // Static method to handle user registration
    public static boolean signUp(ArrayList<Customer> customers, String username, 
                                 String password, String email, int age) {
       
        if (username == null || password == null || email == null ||username.isEmpty() || password.isEmpty()||email.isEmpty()) {
            System.out.println("All fields must be provided.");
            return false;
        }
        
        if (username.equalsIgnoreCase("admin123")) {
            System.out.println("This username is reserved.");
            return false;
        }


        if (age < MIN_AGE || age > MAX_AGE) {
            System.out.println("Age must be between " + MIN_AGE + " and " + MAX_AGE + " years.");
            return false;
        }

        return true;
    }

    // Method to validate login credentials
    public boolean login(String inputUsername, String inputPassword) {
        if (inputUsername == null || inputPassword == null || inputUsername.trim().isEmpty() || inputPassword.trim().isEmpty()) {
            System.out.println("Error: Username and password must be provided and cannot be empty.");
            return false;
        }

        if (this.username.equals(inputUsername.trim()) && this.password.equals(inputPassword.trim())) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Error: Invalid username or password.");
            return false;
        }
    }

    // Helper method to validate email format
    private static boolean validateEmail(String email) {
        return email != null && email.matches(EMAIL_REGEX);
    }

    // Setters and getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String newPassword) {
        if (newPassword != null && newPassword.trim().length() >= MIN_PASSWORD_LENGTH) {
            this.password = newPassword.trim();
            System.out.println("Password updated successfully.");
        } else {
            System.out.println("Error: New password must be at least " + MIN_PASSWORD_LENGTH + " characters long.");
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String newEmail) {
        if (newEmail != null && validateEmail(newEmail)) {
            this.email = newEmail.trim();
            System.out.println("Email updated successfully.");
                    
        } else {
            System.out.println("Error: Invalid email format.");
        }
    }

    // Display user information
    public void getUserInfo() {
        System.out.println("=== User Information ===");
        System.out.println("Username: " + getUsername());
        System.out.println("Email: " + getEmail());
    }

    // Abstract method to display menu; must be implemented by subclasses
    public abstract void displayMenu();
}
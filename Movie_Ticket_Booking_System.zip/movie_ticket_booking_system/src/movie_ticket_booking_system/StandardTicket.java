package movie_ticket_booking_system;

import java.util.Scanner;

public class StandardTicket extends Ticket {
    // Constants for promotion codes and their discounts
    private static final String STUDENT_CODE = "STUDENT_DISCOUNT";
    private static final String SNB_CODE = "SNB10";
    private static final String BLACK_FRIDAY_CODE = "BLACK_FRIDAY";

    private static final double STUDENT_DISCOUNT = 0.15;    // 15% off
    private static final double SNB_DISCOUNT = 0.10;        // 10% off
    private static final double BLACK_FRIDAY_DISCOUNT = 0.30; // 30% off

    // Private member variable
    private String promotionCode;

    // Constructor
    public StandardTicket(Movie movie, int seatRow, int seatColumn, Customer customer) {
        super(movie, seatRow, seatColumn, customer);

        // Ensure row is between 1 and 3 for standard tickets
        if (seatRow < 1 || seatRow > 3) {
            throw new IllegalArgumentException("Standard tickets can only be booked in rows 1-3.");
        }

        // Validate column
        if (seatColumn < 0 || seatColumn >= movie.getSeats()[0].length) {
            throw new IllegalArgumentException("Invalid column selection. Please choose a valid column.");
        }

        this.promotionCode = null; // Initialize with no promotion code
    }

    // Method to set promotion code with validation
    public void setPromotionCode(Scanner scanner) {
        displayAvailablePromotions();

        System.out.println("\nEnter promotion code (or press Enter to skip): ");
        String code = scanner.nextLine().trim().toUpperCase(); // Convert input to uppercase and trim spaces

        if (code.isEmpty()) {
            System.out.println("No promotion code applied.");
            return;
        }

        if (isValidPromotionCode(code)) {
            this.promotionCode = code; // Set the valid promotion code
            System.out.println("Promotion code applied successfully!");
            displayDiscountAmount();
        } else {
            System.out.println("Invalid promotion code. No discount applied.");
        }
    }

    // Display available promotions
    private void displayAvailablePromotions() {
        System.out.println("\n=== Available Promotions ===");
        System.out.println("1. " + STUDENT_CODE + " - " + (STUDENT_DISCOUNT * 100) + "% off for students");
        System.out.println("2. " + SNB_CODE + " - " + (SNB_DISCOUNT * 100) + "% off for SNB cardholders");
        System.out.println("3. " + BLACK_FRIDAY_CODE + " - " + (BLACK_FRIDAY_DISCOUNT * 100) + "% off Black Friday special");
        System.out.println("\nExample: Type 'STUDENT_DISCOUNT' to apply a student discount.");
    }

    // Display the discount amount based on the applied promotion
    private void displayDiscountAmount() {
        double basePrice = super.calculatePrice();
        double discountedPrice = calculatePrice();
        double savings = basePrice - discountedPrice;
        super.setPrice(discountedPrice);
        System.out.printf("You save: $%.2f%n", savings);
    }

    // Override calculatePrice to include promotions
    @Override
    public double calculatePrice() {
        double basePrice = super.calculatePrice();
        
        if (promotionCode == null) { // No promotion applied
            return basePrice;
        }

        switch (promotionCode) {
            case STUDENT_CODE:
                return basePrice * (1 - STUDENT_DISCOUNT);
            case SNB_CODE:
                return basePrice * (1 - SNB_DISCOUNT);
            case BLACK_FRIDAY_CODE:
                return basePrice * (1 - BLACK_FRIDAY_DISCOUNT);
            default:
                return basePrice; // Return base price if the promotion code is invalid
        }
    }

    // Validate promotion code
    private boolean isValidPromotionCode(String code) {
        return code.equals(STUDENT_CODE) || 
               code.equals(SNB_CODE) || 
               code.equals(BLACK_FRIDAY_CODE);
    }

    // Get promotion information
    public void displayPromotionInfo() {
        if (promotionCode == null || promotionCode.isEmpty()) {
            System.out.println("No promotion applied to this ticket.");
            return;
        }

        System.out.println("\n=== Promotion Information ===");
        System.out.println("Applied promotion: " + promotionCode);
        System.out.printf("Discount: %.0f%%%n", getDiscountPercentage() * 100);
    }

    // Helper method to get discount percentage
    private double getDiscountPercentage() {
        switch (promotionCode) {
            case STUDENT_CODE:
                return STUDENT_DISCOUNT;
            case SNB_CODE:
                return SNB_DISCOUNT;
            case BLACK_FRIDAY_CODE:
                return BLACK_FRIDAY_DISCOUNT;
            default:
                return 0.0;
        }
    }

    // Override getTicketInfo to include promotion information
    @Override
    public void getTicketInfo() {
        super.getTicketInfo();
        displayPromotionInfo();
    }

    // Override toString to include promotion information
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());

        if (promotionCode != null && !promotionCode.isEmpty()) {
            sb.append("\nPromotion: ").append(promotionCode)
              .append(" (").append(getDiscountPercentage() * 100).append("% off)");
        }

        return sb.toString();
    }

    // Getter for promotion code
    public String getPromotionCode() {
        return promotionCode;
    }
}
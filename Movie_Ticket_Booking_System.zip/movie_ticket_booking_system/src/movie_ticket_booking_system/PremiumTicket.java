package movie_ticket_booking_system;

import java.util.ArrayList;
import java.util.Scanner;

public class PremiumTicket extends Ticket {
    // Constants for service prices and names
    private static final double SERVICE_PRICE = 20.0;
    private static final String RECLINING_SEATS = "Reclining high-end leather seats";
    private static final String WAITER_SERVICE = "In-cinema Waiter Service";
    private static final String BLANKET_PILLOW = "Complimentary Blanket and Pillow";
    private static final String LUXURY_LOUNGE = "Access to luxury lounge";

    // Attributes
    private ArrayList<String> extraServices;

    // Constructor
    public PremiumTicket(Movie movie, int seatRow, int seatColumn, Customer customer) {
        super(movie, seatRow, seatColumn, customer);

        // Ensure the seat row is 0 for premium tickets
        if (seatRow != 0) {
            throw new IllegalArgumentException("Premium tickets can only be booked in row 0.");
        }

        // Ensure the seat column is valid
        if (seatColumn < 0 || seatColumn >= movie.getSeats()[seatRow].length) {
            throw new IllegalArgumentException("Invalid column selection for premium ticket.");
        }

        // Initialize extra services
        this.extraServices = new ArrayList<>();
        this.extraServices = selectExtraServices();
    }

    // Method to select extra services for the premium ticket
    private ArrayList<String> selectExtraServices() {
        ArrayList<String> selectedServices = new ArrayList<>();
        System.out.println("\n=== Premium Services Selection ===");
        System.out.println("(WARNING: Your choices are final and cannot be changed)");

        // Array of available services
        String[] availableServices = {
            RECLINING_SEATS,
            WAITER_SERVICE,
            BLANKET_PILLOW,
            LUXURY_LOUNGE
        };

        Scanner input = new Scanner(System.in);

        // Loop through each service and ask for the user's selection
        for (String service : availableServices) {
            System.out.println("\nWould you like " + service + "? (0) No (1) Yes");
            System.out.print("Your choice: ");
            int choice;

            // Validate user input to avoid invalid entries
            while (true) {
                if (input.hasNextInt()) {
                    choice = input.nextInt();
                    if (choice == 0 || choice == 1) {
                        break;
                    } else {
                        System.out.println("Invalid choice. Please enter 0 (No) or 1 (Yes).");
                    }
                } else {
                    System.out.println("Invalid input. Please enter 0 (No) or 1 (Yes).");
                    input.next(); // Clear invalid input
                }
            }

            // Process the user's choice
            if (choice == 1) {
                selectedServices.add(service);
                System.out.println(service + " added successfully.");
            } else {
                System.out.println(service + " not added.");
            }
        }

        return selectedServices;
    }

    // Getter for extra services
    public ArrayList<String> getExtraServices() {
        return new ArrayList<>(extraServices); // Return a copy to prevent external modification
    }

    // Override calculatePrice to include extra service costs
    @Override
    public double calculatePrice() {
        double totalPrice = super.calculatePrice(); // Base ticket price

        // Ensure extraServices is not null
        if (extraServices != null) {
            double premiumCharges = extraServices.size() * SERVICE_PRICE;
            totalPrice += premiumCharges; // Add charges for selected premium services
        }
        super.setPrice(totalPrice);
        return totalPrice;
    }

    // Method to display extra services
    public void displayExtraServices() {
        System.out.println("\n=== Premium Services ===");
        if (extraServices.isEmpty()) {
            System.out.println("No extra services selected for this premium ticket.");
        } else {
            System.out.println("Selected services:");
            for (String service : extraServices) {
                System.out.println("- " + service);
            }
            System.out.println("Total premium charges: $" + String.format("%.2f", extraServices.size() * SERVICE_PRICE));
        }
    }

    // Override getTicketInfo to include extra services
    @Override
    public void getTicketInfo() {
        super.getTicketInfo();
        displayExtraServices();
    }

    // Override toString to include premium services
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("\n=== Premium Services ===\n");
        if (extraServices.isEmpty()) {
            sb.append("No extra services selected.");
        } else {
            for (String service : extraServices) {
                sb.append("- ").append(service).append("\n");
            }
            sb.append("Premium charges: $").append(String.format("%.2f", extraServices.size() * SERVICE_PRICE));
        }
        return sb.toString();
    }
}
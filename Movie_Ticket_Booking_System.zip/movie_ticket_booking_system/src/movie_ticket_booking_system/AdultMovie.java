package movie_ticket_booking_system;

public class AdultMovie extends Movie {
    // Constants for violence levels
    public static final String VIOLENCE_LOW = "Low";
    public static final String VIOLENCE_MODERATE = "Moderate";
    public static final String VIOLENCE_HIGH = "High";
    
    // AdultMovie-specific private attributes
    private String leadActor;
    private String director;
    private String violenceLevel;

    // Constructor
    public AdultMovie(String title, String description, Genre genre, int duration, 
                      double rating, String ageRating, int month, int day, 
                      String leadActor, String director, String violenceLevel) {
        
        // Call the Movie constructor
        super(title, description, genre, duration, rating, ageRating, month, day);
        
        // Initialize AdultMovie-specific fields with validation
        setLeadActor(leadActor);
        setDirector(director);
        setViolenceLevel(violenceLevel);
    }

    // Getter for leadActor
    public String getLeadActor() {
        return leadActor;
    }

    // Setter for leadActor with validation
    public void setLeadActor(String leadActor) {
        if (leadActor == null || leadActor.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Lead actor cannot be empty.");
        }
        this.leadActor = leadActor.trim();
    }

    // Getter for director
    public String getDirector() {
        return director;
    }

    // Setter for director with validation
    public void setDirector(String director) {
        if (director == null || director.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Director cannot be empty.");
        }
        this.director = director.trim();
    }

    // Getter for violenceLevel
    public String getViolenceLevel() {
        return violenceLevel;
    }

    // Setter for violenceLevel with validation
    public void setViolenceLevel(String violenceLevel) {
        if (violenceLevel == null || violenceLevel.trim().isEmpty()) {
            throw new IllegalArgumentException("Error: Violence level cannot be empty.");
        }
        
        String level = violenceLevel.trim();
        if (!isValidViolenceLevel(level)) {
            throw new IllegalArgumentException("Error: Invalid violence level. Must be 'Low', 'Moderate', or 'High'.");
        }
        
        this.violenceLevel = level;
    }

    // Helper method to validate violence level
    private boolean isValidViolenceLevel(String level) {
        return level.equalsIgnoreCase(VIOLENCE_LOW) || 
               level.equalsIgnoreCase(VIOLENCE_MODERATE) || 
               level.equalsIgnoreCase(VIOLENCE_HIGH);
    }

    // Override toString method to include adult-specific information
    @Override
    public String toString() {
        return super.toString();
    }

    // Override getMovieInfo method to include adult-specific information
    @Override
    public String[] getMovieInfo() {
        String[] basicInfo = super.getMovieInfo();
        String[] adultInfo = new String[basicInfo.length + 3];
        
        // Copy basic movie info
        System.arraycopy(basicInfo, 0, adultInfo, 0, basicInfo.length);
        
        // Add adult movie-specific info
        adultInfo[basicInfo.length] = "Lead Actor: " + leadActor;
        adultInfo[basicInfo.length + 1] = "Director: " + director;
        adultInfo[basicInfo.length + 2] = "Violence Level: " + violenceLevel;
        
        return adultInfo;
    }
}